/**
* @file student.c
* @author Sharmin Ahmed
* @version 1.0
* @date 2022-04-08
* @brief A compilation of functions to be used in main.c relating to a Student.
*
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
* Adds a grade to the provided student's array of grades.
* 
* @param student a student with a name, id and grades  
* @param double a grade 
* @return nothing
* 
*/ 
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  
  // if the student has one course grade allocate memory for the grade using 
  // calloc. otherwise use realloc to allocate memory for the grade
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  // add the course grade to the student's array of grades
  student->grades[student->num_grades - 1] = grade;
}

/**
* Computes a student's grade average.
* 
* @param student a student with a name, id and grades  
* @return double the student's average
* 
*/ 
double average(Student* student)
{
  // if the student is no courses return 0
  if (student->num_grades == 0) return 0;

  // add all the student's grades with a for loop and return their average
  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
* Prints a student along with all their corresponding information.
* 
* @param student a student with a name, id and grades  
* @return nothing
* 
*/ 
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  // use a for loop to print all of the student grades
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
* Randomly generates a new student including their name, id and a set of grades.
* 
* @param int the number of grades a student has
* @return student a student with a name, id and grades
* 
*/ 
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  // create a new student by allocating memory with calloc
  Student *new_student = calloc(1, sizeof(Student));

  // randomly assign names from the provided array of names
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // randomly assign a 10 character long student id
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  // use add_grade to randomly add the desired number of grades to the student
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}