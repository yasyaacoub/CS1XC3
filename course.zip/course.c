/**
* @file course.c
* @author Sharmin Ahmed
* @version 1.0
* @date 2022-04-08
* @brief A compilation of functions to be used in main.c relating to the Course.
*
*/

#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
* Adds a student to the provided course.
* 
* @param course a course with an assigned name, code and students
* @param student a student with a name, id and grades  
* @return nothing
* 
*/ 
void enroll_student(Course *course, Student *student)
{
  // add 1 to the total students, if there is only one student the allocate
  // memory with calloc in the course for this student, else use realloc to 
  // allocate memory for this student
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  // add this student to the students in the course
  course->students[course->total_students - 1] = *student;
}

/**
* Prints the provided course and all its information.
* 
* @param course a course with an assigned name, code and students
* @return nothing
* 
*/ 
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  // loops through all the students in the course, printing each one 
  // with the print_student function
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
* Determines the top student of the provided course.
* 
* @param course a course with an assigned name, code and students
* @return student the top student of the course
* 
*/ 
Student* top_student(Course* course)
{
  // if there are no students in the course return nothing
  if (course->total_students == 0) return NULL;
 
  // assign the max average to the first student by calling the function average
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  // find the maximum average by using a for loop to get each student average with
  // the function average.
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    
    // compares the average of the max student with the current student. if the current
    // has a higher average, set the current average to the max average
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}


/**
* Determines the students passing the provided course.
* 
* @param course a course with an assigned name, code and students
* @param int pointer to reference the number of passing students
* @return student the course's passing students 
* 
*/ 
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  // use a for loop to count the number of students passing the course 
  // by calling the function average
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  // allocate enough memory in passing with calloc to store all the passing students
  passing = calloc(count, sizeof(Student));

  // use a for loop to add all the students passing the course to passing
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}