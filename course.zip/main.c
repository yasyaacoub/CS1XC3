/**
* @mainpage Course and student function demonstration.
* 
* This uses multiple course and student and functions to create a course and enroll
* 20 random students in the course. Functions used include those who:
* - enroll students
* - generate a random student
* - printing a course
* 
* @file main.c
* @author Sharmin Ahmed
* @version 1.0
* @date 2022-04-08
* @brief Creates a course, enrolls students into the course, and uses methods on them. 
* 
*/

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
* Creates a course MATH101 and enrolls 20 randomly generated students into the course. 
* Computes the top student and number of students passing the course and prints them.
*
*/
int main()
{
  // seeds random number generator
  srand((unsigned) time(NULL));

  // create room for one course, MATH101 and name the course
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  // enroll 20 random students with 8 courses each in MATH101 
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  // create a student and assigns it the top student of MATH101m then print the student
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  // create a student and assign it the students passing MATH101, then print these students
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}